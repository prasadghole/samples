﻿using System;

namespace SampleTest
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, world!");
        }

        public static int Add(int a, int b)
        {
            return a + b;
        }
    }
}